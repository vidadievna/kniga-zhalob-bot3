
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils import executor
from aiogram.dispatcher.filters import CommandStart
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.types.message import ContentType

API_TOKEN = "8016743030:AAEy-uS8Kzz0LE41zj3GZ5jFU9ebqZXt1XY"
CHANNEL_ID = "@ustalprisholrasskazat"
MODERATOR_ID = 584541756  # Твой Telegram ID

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot, storage=MemoryStorage())

pending_messages = {}

@dp.message_handler(CommandStart())
async def start(message: types.Message):
    logging.info(f"[START] Пользователь {message.from_user.id} нажал /start")
    await message.reply("Привет. Напиши, что у тебя случилось сегодня — это анонимно появится в 'Книге жалоб' (после модерации).")

@dp.message_handler(content_types=ContentType.TEXT)
async def handle_message(message: types.Message):
    user = message.from_user
    msg_id = message.message_id
    text = message.text
    user_info = f"@{user.username}" if user.username else f"ID: {user.id}"

    logging.info(f"[NEW MESSAGE] От {user_info}: {text}")

    pending_messages[str(msg_id)] = {
        "text": text,
        "user_id": user.id
    }

    kb = InlineKeyboardMarkup(row_width=2)
    kb.add(
        InlineKeyboardButton("✅ Опубликовать", callback_data=f"approve:{msg_id}"),
        InlineKeyboardButton("❌ Отклонить", callback_data=f"reject:{msg_id}")
    )

    try:
        await bot.send_message(
            chat_id=MODERATOR_ID,
            text="💬 Новое сообщение:\n\n\"{}\"\n\n👤 Отправитель: {}".format(text, user_info),
            reply_markup=kb
        )
        logging.info(f"[SENT TO MODERATOR] Сообщение от {user_info} отправлено модератору.")
    except Exception as e:
        logging.error(f"[ERROR] Не удалось отправить модератору: {e}")

@dp.callback_query_handler(lambda c: c.data.startswith(("approve", "reject")))
async def handle_callback(callback_query: types.CallbackQuery):
    action, msg_id = callback_query.data.split(":")
    data = pending_messages.get(msg_id)

    if not data:
        await callback_query.answer("Сообщение не найдено или уже обработано.", show_alert=True)
        return

    if action == "approve":
        text = data["text"]
        try:
            await bot.send_message(
                chat_id=CHANNEL_ID,
                text='💬 Кто-то делится:\n"{}"'.format(text),
                reply_markup=InlineKeyboardMarkup().add(
                    InlineKeyboardButton("Пиздец, я в ахуе (0)", callback_data=f"react:0:{msg_id}")
                )
            )
            logging.info(f"[PUBLISHED] Сообщение {msg_id} опубликовано в канале.")
        except Exception as e:
            logging.error(f"[ERROR] Не удалось опубликовать сообщение: {e}")
        pending_messages.pop(msg_id, None)
        await callback_query.message.edit_reply_markup()
        await callback_query.answer("Опубликовано.")
    elif action == "reject":
        pending_messages.pop(msg_id, None)
        logging.info(f"[REJECTED] Сообщение {msg_id} отклонено.")
        await callback_query.message.edit_reply_markup()
        await callback_query.answer("Отклонено.")

@dp.callback_query_handler(lambda c: c.data.startswith("react"))
async def handle_reaction(callback_query: types.CallbackQuery):
    _, count, msg_id = callback_query.data.split(":")
    new_count = int(count) + 1
    new_text = "Пиздец, я в ахуе ({})".format(new_count)
    await callback_query.message.edit_reply_markup(
        InlineKeyboardMarkup().add(
            InlineKeyboardButton(new_text, callback_data=f"react:{new_count}:{msg_id}")
        )
    )
    logging.info(f"[REACTION] Кто-то нажал кнопку под постом {msg_id}. Счётчик теперь {new_count}.")
    await callback_query.answer("😮")

if __name__ == "__main__":
    logging.info("Бот запущен. Ожидание сообщений...")
    executor.start_polling(dp, skip_updates=True)
